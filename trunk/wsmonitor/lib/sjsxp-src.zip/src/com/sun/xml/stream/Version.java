/*
 * Version.java
 *
 * This class prints the version information of the Parser.
 */

package com.sun.xml.stream;

/**
 *
 * @author Neeraj Bajaj
 */
public class Version {
    
    /** Creates a new instance of Version */
    public Version() {
    }
    
    public static void main(String [] args){
        System.out.println("Sun Java Streaming XML Parser Version is " + "'" + Package.getPackage("com.sun.xml.stream").getImplementationVersion() + "'");        
    }
    
}
